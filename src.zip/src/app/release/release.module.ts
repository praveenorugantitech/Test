import { NgModule } from "@angular/core";
import { AsyncPipe, CommonModule } from "@angular/common";

import { ReleaseRoutingModule } from "./release-routing.module";
import { ReleaseComponent } from "./release.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { FirmwareDescriptionAndOwnersComponent } from './components/help/firmware-description-and-owners/firmware-description-and-owners.component';
import { UserEnrollmentComponent } from './components/help/user-enrollment/user-enrollment.component';
import { AdvanceSearchComponent } from './components/lookup-release-info/advance-search/advance-search.component';
import { ConcernNoticeComponent } from './components/lookup-release-info/concern-notice/concern-notice.component';
import { AddNewPartIiOrPdxComponent } from './components/module-release/add-new-part-ii-or-pdx/add-new-part-ii-or-pdx.component';
import { AddPblComponent } from './components/module-release/add-pbl/add-pbl.component';
import { AddSblComponent } from './components/module-release/add-sbl/add-sbl.component';
import { FedebomPlaceholderReleaseComponent } from './components/module-release/fedebom-placeholder-release/fedebom-placeholder-release.component';
import { MyQueueComponent } from './components/module-release/my-queue/my-queue.component';
import { RequestNewMainMicroTypeComponent } from './components/module-release/request-new-main-micro-type/request-new-main-micro-type.component';
import { CoordinatedModuleMatrixComponent } from './components/output-release-info/coordinated-module-matrix/coordinated-module-matrix.component';
import { FordIvsCalibrationDownloadComponent } from './components/output-release-info/ford-ivs-calibration-download/ford-ivs-calibration-download.component';
import { FordProgramReportComponent } from './components/output-release-info/ford-program-report/ford-program-report.component';
import { PrismInputComponent } from './components/output-release-info/prism-input/prism-input.component';
import { SoftwareDrawingComponent } from './components/output-release-info/software-drawing/software-drawing.component';
import { WersPowerSelectTableComponent } from './components/output-release-info/wers-power-select-table/wers-power-select-table.component';
import { XmlComponent } from './components/output-release-info/xml/xml.component';
import { CalibrationEngineerComponent } from './components/procedures/calibration-engineer/calibration-engineer.component';
import { ReleaseEngineerComponent } from './components/procedures/release-engineer/release-engineer.component';
import { SoftwareReleaseAnalystComponent } from './components/procedures/software-release-analyst/software-release-analyst.component';
import { SupplierCalibrationDownloadComponent } from './components/supplier-request/supplier-calibration-download/supplier-calibration-download.component';
import { SupplierIvsCalibrationDownloadComponent } from './components/supplier-request/supplier-ivs-calibration-download/supplier-ivs-calibration-download.component';
import { SidebarModule } from 'primeng/sidebar';
import { AccordionModule } from 'primeng/accordion';
import { RouterOutlet } from "@angular/router";
import { InputTextModule } from 'primeng/inputtext';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { AutoCompleteModule } from 'primeng/autocomplete';

@NgModule({
  declarations: [
    ReleaseComponent,
    FirmwareDescriptionAndOwnersComponent,
    UserEnrollmentComponent,
    AdvanceSearchComponent,
    ConcernNoticeComponent,
    AddNewPartIiOrPdxComponent,
    AddPblComponent,
    AddSblComponent,
    FedebomPlaceholderReleaseComponent,
    MyQueueComponent,
    RequestNewMainMicroTypeComponent,
    CoordinatedModuleMatrixComponent,
    FordIvsCalibrationDownloadComponent,
    FordProgramReportComponent,
    PrismInputComponent,
    SoftwareDrawingComponent,
    WersPowerSelectTableComponent,
    XmlComponent,
    CalibrationEngineerComponent,
    ReleaseEngineerComponent,
    SoftwareReleaseAnalystComponent,
    SupplierCalibrationDownloadComponent,
    SupplierIvsCalibrationDownloadComponent

  ],
  imports: [
    CommonModule,
    ReleaseRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AsyncPipe,
    SidebarModule,
    AccordionModule,
    ButtonModule,
    RouterOutlet,
    InputTextModule,
    DropdownModule,
    CardModule,
    InputTextareaModule,
    AutoCompleteModule    


  ],
})
export class ReleaseModule { }
