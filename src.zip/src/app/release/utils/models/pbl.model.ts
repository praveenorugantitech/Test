export class AddPblData {
  newPbl: string = "";
  moduleTypeCode: string = "";
  createUser: string = "";
  lastUpdateUser: string = "";
}

export class FetchPartDetails {
  newPbl: string = "";
  currentPbl: string = "";
}

export class PartFirmware {
  firmwareN: string = "";
  fileN: string = "";
  aprvdByCdsidC: string = "";
  firmwareCatgN: string = "";
  aprvdY: string = "";
}

export class PartFirmwareRecord {
  assemblyPN: string = "";
  drcdsId: string = "";
  hardwarePN: string = "";
  coreHardwarePN: string = "";
  mainMicroType: string = "";
  programDescriptions: ProgramDescription[] = [];
  lineage: string = "";
  partFirmwares: PartFirmware[] = [];
}

export class ProgramDescription {
  pgmK: Number = 0;
  mdlYrR: string = "";
  pgmN: string = "";
  platN: string = "";
  engN: string = "";
  transN: string = "";
}

export class ReplacePblPutModel {
  newPbl: string = "";
  moduleTypeCode: string = "";
  createUser: string = "";
  lastUpdateUser: string = "";
  partNumbers: string[] = [];
}

export class PblModel {
  releaseType: string = "new_pbl";
  moduleTypeCode: string = "";
  moduleTypeName: string = "";
  currentPbl: string = "";
  newPbl: string = "";
}
