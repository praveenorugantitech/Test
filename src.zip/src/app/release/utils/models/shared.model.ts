export class SupplierOptionsModel {
  supplierName: string = "";
  supplierCode: string = "";
}
export class ModuleTypesOptionsModel {
  moduleTypeName: string = "";
  moduleTypeCode: string = "";
}
export class MicroTypesOptionModel {
  microTypeCode: number = 0;
  microTypeName: string = "";
}

export class ReleaseTypesOptionModel {
  releaseTypeCode: string = "";
  releaseTypeName: string = "";
}

export class ModuleNamesOptionsModel {
  moduleName: string = "";
}

export class MicroNamesOptionsModel {
  microName: string = "";
}
