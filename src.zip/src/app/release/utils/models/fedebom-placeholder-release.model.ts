export class FedebomReleaseModel {
  releaseTypeCode?: string = "";
  releaseTypeName?: string = "";
  sraComment?: string = "";
  moduleTypeCode?: string = "";
  hardwarePartNumbers: string[] = []; 
}

export interface FedebomPlaceholderReleasePart {
  pnPrefix: string;
  hardwarePn: string;
}


export interface FedebomPlaceholderReleasePartRequest {
  moduleTypeCode: string;
  releaseTypeCode: string;
  userId: string;
  sraComment: string;
  fedebomPlaceholderReleaseParts: FedebomPlaceholderReleasePart[];
}
