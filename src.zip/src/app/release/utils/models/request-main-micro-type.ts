export class AddRequestMainMicroTypeModel {
  moduleTypeCode: string = "";
  moduleTypeName: string = "";
  supplierCode: string = "";
  supplierName: string = "";
  moduleFamily: string = "";
  moduleName: string = "";
  microName: string = "";
  mainMicroTypeName: string = "";
  internalFlashMemorySize: string = "";
  microNonPCMName: string = "";
}

export class AddPostRequestMainMicroTypeModel {
  mainMicroTypeName: string = "";
  createUser: string = "";
  lastUpdateUser: string = "";
  moduleTypeCode: string = "";
  supplierCode: string = "";
  supplierName: string = "";
}
