export class FindProductionPartNumberModel {
  pnPre: string = "";
  pnBase: string = "";
  pnSuffix: string = "";
  wersNotice: string = "";
  catchWord: string = "";
  swpnPre: string = "";
  swpnBase: string = "";
  swpnSuffix: string = "";
  calibrationNumber: string = "";
  stratRelName: string = "";
  chipID: string = "";
}

export class FindProductionPartNumberPostModel {
  partNumber: string = "";
  wersNotice: string = "";
  catchWord: string = "";
  softwarePartNumber: string = "";
  calibrationNumber: string = "";
  stratRelName: string = "";
  chipID: string = "";
}

export interface ProductionPartNumberRecord {
  partNumber: string;
  catchWord: string;
  calibrationNumber: string;
  softwarePN: string;
  hardwarePN: string;
  mainMicroType: string;
  wersNotice: string;
}
