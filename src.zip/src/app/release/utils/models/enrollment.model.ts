export class Enrollment {
  userId?: string = "";
  firstName?: string = "";
  lastName?: string = "";
  emailAddress?: string = "";
  comments?: string = "";
}
