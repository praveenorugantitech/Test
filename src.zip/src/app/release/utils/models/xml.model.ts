export class FirmwareExportForm {
  exportVersion: number = 10;
  exportFilename!: string;
  concernNumber!: string;
  wersNoticeNumber!: string;
  partNumbers: string[] = Array(9).fill("");
}

export class ExportToXmlPostModel {
  partNumbers: string[] = [];
  exportFilename: string = "";
  concernNumber: string = "";
  wersNoticeNumber: string = "";
  exportVersion: number = 10;
  createUser: string = "";
}
