import { Component, OnInit } from '@angular/core';
import { UrlManager } from '../utils/shared-constants.model';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { ReleaseSideBarMenuModel } from './utils/models/release-sidebar.model';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-release',
  templateUrl: './release.component.html',
  styleUrls: ['./release.component.scss']
})
export class ReleaseComponent implements OnInit {

  urlMngr: UrlManager;
  showMainContent: boolean = false;

  MENU_ITEMS: Array<ReleaseSideBarMenuModel> = [
    {
      id: 'module_release',
      name: 'Module Release',
      url: '',
      iconName: 'share-alt',
      children: [
        { id: 'my_queue', name: 'My Queue', url: 'MY_QUEUE' },
        { id: 'start_release', name: 'Start Release', url: 'START_RELEASE' },
        { id: 'fedebom_place_holder_release', name: 'FEDEBOM Placeholder Release', url: 'FEDEBOM_PLACEHOLDER_RELEASE' },
        { id: 'atartrelease_request', name: 'Start Release Request', url: 'START_RELEASE_REQUEST' },
        { id: 'request_new_main_micro_type', name: 'Request New Main Micro Type', url: 'REQUEST_NEW_MAIN_MICRO_TYPE' },
        { id: 'add_new_part_II_or_pdx', name: 'Add New Part II or PDX', url: 'ADD_NEW_PART_II_OR_PDX' },
        { id: 'add_new_bpl', name: 'Add New PBL', url: 'ADD_NEW_PBL' },
        { id: 'add_new_sbl', name: 'Add New SBL', url: 'ADD_NEW_SBL' },
      ],
    },
    {
      id: 'lookup_release_info',
      name: 'Lookup Release Info',
      url: '',
      iconName: 'eye',
      children: [
        { id: 'concem_notice', name: 'Concern / Notice', url: 'CONCERN_NOTICE' },
        { id: 'advanced_search', name: 'Advanced Search', url: 'ADVANCED_SEARCH' },
      ],
    },
    {
      id: 'help',
      name: 'Help',
      url: '',
      iconName: 'info-circle',
      children: [
        { id: 'user_enrollment', name: 'User Enrollment', url: 'USER_ENROLLMNET' },
        { id: 'bulk_mall_guide', name: 'Bulk Mail Guide', url: 'BULK_MAIL_GUIDE' },
        { id: 'process_owners', name: 'Process Owners', url: 'PROCESS_OWNERS' },
        { id: 'gpcse_module_release_process', name: 'GPCSE Module Release Process', url: 'GPCSE_MODULE_RELEASE_PROCESS' },
        { id: 'firmware_descriptions_and_owners', name: 'Firmware Descriptions and Owners', url: 'FIRMWARE_DESCRIPTION_AND_OWNERS' },
        { id: 'jira_service_desk', name: 'JIRA Service Desk', url: 'JIRA_SERVICE_DESK' },
      ],
    },
    {
      id: 'output_release_info',
      name: 'Output Release Info',
      url: '',
      iconName: 'download',
      children: [
        { id: 'xml', name: 'XML', url: 'XML' },
        { id: 'prism_input', name: 'PRISM Input', url: 'PRISM_INPUT' },
        { id: 'ford-ivs-calibration-download', name: 'Ford IVS Calibration Download', url: 'FORD_IVS_CALIBRATION_DOWNLOAD' },
        { id: 'ford-program-report', name: 'Ford Program Report', url: 'FORD_PROGRAM_REPORT' },
        { id: 'coordinated-module-matrix', name: 'Coordinated Module Matrix', url: 'COORDINATED_MODULE_MATRIX' },
        { id: 'wers-power-select-table', name: 'WERS Power Select Table', url: 'WERS_POWER_SELECT_TABLE' },
        { id: 'software-drawing', name: 'Software Drawing', url: 'SOFTWARE_DRAWING' },
      ],
    },
    {
      id: 'supplier_request',
      name: 'Supplier Request',
      url: '',
      iconName: 'user-plus',
      children: [
        { id: 'supplier_user_enrollment', name: 'Supplier User Enrollment', url: 'SUPPLIER_USER_ENROLLMNET' },
        { id: 'supplier_calibration_download', name: 'Supplier Calibration Download', url: 'SUPPLIER_CALIBRATION_DOWNLOAD' },
        { id: 'supplier_ivs_calibration_download', name: 'Supplier IVS Calibration Download', url: 'SUPPLIER_IVS_CALIBRATION_DOWNLOAD' },
      ],
    },
    {
      id: 'procedures',
      name: 'Procedures',
      url: '',
      iconName: 'list',
      children: [
        { id: 'calbration_engineer', name: 'Calibration Engineer', url: 'CALIBRATION_ENGINEER' },
        { id: 'release_engineer', name: 'Release Engineer', url: 'RELEASE_ENGINEER' },
        { id: 'software_release_analyst', name: 'Software Release Analyst', url: 'SOFTWARE_RELEASE_ANALYST' },
      ],
    },
    {
      id: 'administrative',
      name: 'Administrative',
      url: '',
      iconName: 'cog',
      children: [
        { id: 'firmware_database_administration', name: 'Firmware Database Administration', url: 'FIRMWARE_DATABASE_ADMINISTRATION' },
        { id: 'module_release_sharepoint', name: 'Module Release Sharepoint', url: 'MODULE_RELEASE_SHAREPOINT' },
      ],
    },
  ];


  constructor(private router: Router, private activatedRoute: ActivatedRoute) {
    this.urlMngr = new UrlManager();
  }


  ngOnInit(): void {
    this.checkPath();
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe(() => {
      this.checkPath();
    });
  }

  checkPath(): void {
    const currentPath = this.router.url.split('?')[0];
    this.showMainContent = currentPath === '/release';
  }

  getAccordionHeader(menuItem: ReleaseSideBarMenuModel): string {
    return `
      <div class="header-content">
        <i class="pi pi-${menuItem.iconName}"></i>
        <span class="menu-name">${menuItem.name}</span>
        <span class="pi pi-chevron-down accordion-icon" style="float: right;"></span>
      </div>
    `;
  }
}
