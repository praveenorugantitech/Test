import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ReleaseComponent } from "./release.component";

import { AddSblComponent } from "./components/module-release/add-sbl/add-sbl.component";
import { AddPblComponent } from "./components/module-release/add-pbl/add-pbl.component";
import { AddNewPartIiOrPdxComponent } from "./components/module-release/add-new-part-ii-or-pdx/add-new-part-ii-or-pdx.component";
import { RequestNewMainMicroTypeComponent } from "./components/module-release/request-new-main-micro-type/request-new-main-micro-type.component";
import { CalibrationEngineerComponent } from "./components/procedures/calibration-engineer/calibration-engineer.component";
import { ReleaseEngineerComponent } from "./components/procedures/release-engineer/release-engineer.component";
import { SoftwareReleaseAnalystComponent } from "./components/procedures/software-release-analyst/software-release-analyst.component";
import { ConcernNoticeComponent } from "./components/lookup-release-info/concern-notice/concern-notice.component";
import { AdvanceSearchComponent } from "./components/lookup-release-info/advance-search/advance-search.component";
import { UserEnrollmentComponent } from "./components/help/user-enrollment/user-enrollment.component";
import { FirmwareDescriptionAndOwnersComponent } from "./components/help/firmware-description-and-owners/firmware-description-and-owners.component";
import { SupplierCalibrationDownloadComponent } from "./components/supplier-request/supplier-calibration-download/supplier-calibration-download.component";
import { SupplierIvsCalibrationDownloadComponent } from "./components/supplier-request/supplier-ivs-calibration-download/supplier-ivs-calibration-download.component";
import { XmlComponent } from "./components/output-release-info/xml/xml.component";
import { PrismInputComponent } from "./components/output-release-info/prism-input/prism-input.component";
import { FordIvsCalibrationDownloadComponent } from "./components/output-release-info/ford-ivs-calibration-download/ford-ivs-calibration-download.component";
import { FordProgramReportComponent } from "./components/output-release-info/ford-program-report/ford-program-report.component";
import { CoordinatedModuleMatrixComponent } from "./components/output-release-info/coordinated-module-matrix/coordinated-module-matrix.component";
import { WersPowerSelectTableComponent } from "./components/output-release-info/wers-power-select-table/wers-power-select-table.component";
import { SoftwareDrawingComponent } from "./components/output-release-info/software-drawing/software-drawing.component";
import { FileDownloadComponent } from "../utils/file-download/file-download.component";
import { MyQueueComponent } from "./components/module-release/my-queue/my-queue.component";
import { environment } from "../../environments/environment";
import { FedebomPlaceholderReleaseComponent } from "./components/module-release/fedebom-placeholder-release/fedebom-placeholder-release.component";
import { Error404Component } from "../error-page/error-404/error-page.component";
const routes: Routes = [
  {
    path: "",
    component: ReleaseComponent,
    children: [
      ...(environment.enableAllRoutes
        ? [
          {
            path: "myqueue",
            component: MyQueueComponent,
            data: { title: "My Queue" },
          },
          {
            path: "fedebom-placeholder-release",
            component: FedebomPlaceholderReleaseComponent,
            data: { title: "Fedebom Placeholder Release" },
          },
          {
            path: "add-new-sbl",
            component: AddSblComponent,
            data: { title: "Add SBL" },
          },
          {
            path: "add-new-pbl",
            component: AddPblComponent,
            data: { title: "Add PBL Firmware" },
          },
          {
            path: "add-new-part-II-or-pdx",
            component: AddNewPartIiOrPdxComponent,
            data: { title: "Add Part II or PDX" },
          },
          {
            path: "request-new-main-micro-type",
            component: RequestNewMainMicroTypeComponent,
            data: { title: "Request New Main Micro Type" },
          },
          {
            path: "calibration-engineer",
            component: CalibrationEngineerComponent,
          },
          { path: "release-engineer", component: ReleaseEngineerComponent },
          {
            path: "software-release-analyst",
            component: SoftwareReleaseAnalystComponent,
          },

          {
            path: "concern-notice",
            component: ConcernNoticeComponent,
            data: { title: "Concern / Notice" },
          },
          {
            path: "advanced-search",
            component: AdvanceSearchComponent,
          },
          {
            path: "user-enrollment",
            component: UserEnrollmentComponent,
            data: { title: "User Enrollment" },
          },
          {
            path: "firmware-description-and-owners",
            component: FirmwareDescriptionAndOwnersComponent,
            data: { title: "Firware Description" },
          },
          {
            path: "supplier-calibration-download",
            component: SupplierCalibrationDownloadComponent,
          },
          {
            path: "supplier-ivs-calibration-download",
            component: SupplierIvsCalibrationDownloadComponent,
          },
          { path: "xml", component: XmlComponent },
          { path: "prism-input", component: PrismInputComponent },
          {
            path: "ford-ivs-calibration-download",
            component: FordIvsCalibrationDownloadComponent,
          },
          {
            path: "ford-program-report",
            component: FordProgramReportComponent,
          },
          {
            path: "coordinated-module-matrix",
            component: CoordinatedModuleMatrixComponent,
          },
          {
            path: "wers-power-select-table",
            component: WersPowerSelectTableComponent,
          },
          { path: "software-drawing", component: SoftwareDrawingComponent },
          { path: "bulk-mail-guide", component: FileDownloadComponent },
          { path: "process-owners", component: FileDownloadComponent },
          {
            path: "gpcse-module-release-process",
            component: FileDownloadComponent,
          },
          { path: "jira-service-desk", component: FileDownloadComponent },
          {
            path: "module-release-sharepoint",
            component: FileDownloadComponent,
          },
          { path: "**", component: Error404Component },
        ]
        : []),
      ...(environment.enableLimitedRoutes
        ? [
          {
            path: "myqueue",
            component: MyQueueComponent,
            data: { title: "My Queue" },
          },
          {
            path: "fedebom-placeholder-release",
            component: FedebomPlaceholderReleaseComponent,
            data: { title: "Fedebom Placeholder Release" },
          },
          {
            path: "add-new-sbl",
            component: AddSblComponent,
            data: { title: "Add SBL" },
          },
          {
            path: "add-new-pbl",
            component: AddPblComponent,
            data: { title: "Add PBL Firmware" },
          },
          {
            path: "add-new-part-II-or-pdx",
            component: AddNewPartIiOrPdxComponent,
            data: { title: "Add Part II or PDX" },
          },
          {
            path: "request-new-main-micro-type",
            component: RequestNewMainMicroTypeComponent,
            data: { title: "Request New Main Micro Type" },
          },

          {
            path: "concern-notice",
            component: ConcernNoticeComponent,
            data: { title: "Concern / Notice" },
          },
          {
            path: "advanced-search",
            component: AdvanceSearchComponent,
          },
          {
            path: "user-enrollment",
            component: UserEnrollmentComponent,
            data: { title: "User Enrollment" },
          },
          { path: "bulk-mail-guide", component: FileDownloadComponent },
          { path: "process-owners", component: FileDownloadComponent },
          {
            path: "gpcse-module-release-process",
            component: FileDownloadComponent,
          },
          {
            path: "firmware-description-and-owners",
            component: FirmwareDescriptionAndOwnersComponent,
            data: { title: "Firware Description" },
          },
          { path: "jira-service-desk", component: FileDownloadComponent },
          { path: "xml", component: XmlComponent },
          { path: "prism-input", component: PrismInputComponent },
          {
            path: "module-release-sharepoint",
            component: FileDownloadComponent,
          },
          { path: "**", component: Error404Component },
        ]
        : []),
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReleaseRoutingModule { }
