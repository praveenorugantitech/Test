import { Component } from '@angular/core';

@Component({
  selector: 'app-add-pbl',
  templateUrl: './add-pbl.component.html',
  styleUrls: ['./add-pbl.component.scss']
})
export class AddPblComponent {

}
