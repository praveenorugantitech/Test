import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSblComponent } from './add-sbl.component';

describe('AddSblComponent', () => {
  let component: AddSblComponent;
  let fixture: ComponentFixture<AddSblComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddSblComponent]
    });
    fixture = TestBed.createComponent(AddSblComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
