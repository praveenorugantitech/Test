import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestNewMainMicroTypeComponent } from './request-new-main-micro-type.component';

describe('RequestNewMainMicroTypeComponent', () => {
  let component: RequestNewMainMicroTypeComponent;
  let fixture: ComponentFixture<RequestNewMainMicroTypeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RequestNewMainMicroTypeComponent]
    });
    fixture = TestBed.createComponent(RequestNewMainMicroTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
