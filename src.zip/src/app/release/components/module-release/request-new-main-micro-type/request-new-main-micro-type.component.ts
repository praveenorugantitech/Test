import { Component } from '@angular/core';

@Component({
  selector: 'app-request-new-main-micro-type',
  templateUrl: './request-new-main-micro-type.component.html',
  styleUrls: ['./request-new-main-micro-type.component.scss']
})
export class RequestNewMainMicroTypeComponent {

}
