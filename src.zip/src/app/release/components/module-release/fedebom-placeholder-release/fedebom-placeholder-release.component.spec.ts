import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FedebomPlaceholderReleaseComponent } from './fedebom-placeholder-release.component';

describe('FedebomPlaceholderReleaseComponent', () => {
  let component: FedebomPlaceholderReleaseComponent;
  let fixture: ComponentFixture<FedebomPlaceholderReleaseComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FedebomPlaceholderReleaseComponent]
    });
    fixture = TestBed.createComponent(FedebomPlaceholderReleaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
