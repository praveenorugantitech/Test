import { Component } from '@angular/core';

@Component({
  selector: 'app-fedebom-placeholder-release',
  templateUrl: './fedebom-placeholder-release.component.html',
  styleUrls: ['./fedebom-placeholder-release.component.scss']
})
export class FedebomPlaceholderReleaseComponent {

}
