import { Component } from '@angular/core';

@Component({
  selector: 'app-add-new-part-ii-or-pdx',
  templateUrl: './add-new-part-ii-or-pdx.component.html',
  styleUrls: ['./add-new-part-ii-or-pdx.component.scss']
})
export class AddNewPartIiOrPdxComponent {

}
