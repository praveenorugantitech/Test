import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNewPartIiOrPdxComponent } from './add-new-part-ii-or-pdx.component';

describe('AddNewPartIiOrPdxComponent', () => {
  let component: AddNewPartIiOrPdxComponent;
  let fixture: ComponentFixture<AddNewPartIiOrPdxComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddNewPartIiOrPdxComponent]
    });
    fixture = TestBed.createComponent(AddNewPartIiOrPdxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
