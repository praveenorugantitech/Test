import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CalibrationEngineerComponent } from './calibration-engineer.component';

describe('CalibrationEngineerComponent', () => {
  let component: CalibrationEngineerComponent;
  let fixture: ComponentFixture<CalibrationEngineerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CalibrationEngineerComponent]
    });
    fixture = TestBed.createComponent(CalibrationEngineerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
