import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReleaseEngineerComponent } from './release-engineer.component';

describe('ReleaseEngineerComponent', () => {
  let component: ReleaseEngineerComponent;
  let fixture: ComponentFixture<ReleaseEngineerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ReleaseEngineerComponent]
    });
    fixture = TestBed.createComponent(ReleaseEngineerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
