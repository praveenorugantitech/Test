import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SoftwareReleaseAnalystComponent } from './software-release-analyst.component';

describe('SoftwareReleaseAnalystComponent', () => {
  let component: SoftwareReleaseAnalystComponent;
  let fixture: ComponentFixture<SoftwareReleaseAnalystComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SoftwareReleaseAnalystComponent]
    });
    fixture = TestBed.createComponent(SoftwareReleaseAnalystComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
