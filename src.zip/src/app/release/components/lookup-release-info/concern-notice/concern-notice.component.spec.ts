import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConcernNoticeComponent } from './concern-notice.component';

describe('ConcernNoticeComponent', () => {
  let component: ConcernNoticeComponent;
  let fixture: ComponentFixture<ConcernNoticeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ConcernNoticeComponent]
    });
    fixture = TestBed.createComponent(ConcernNoticeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
