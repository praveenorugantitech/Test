import { Component } from '@angular/core';

@Component({
  selector: 'app-concern-notice',
  templateUrl: './concern-notice.component.html',
  styleUrls: ['./concern-notice.component.scss']
})
export class ConcernNoticeComponent {

}
