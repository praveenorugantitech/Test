import { Component } from '@angular/core';

@Component({
  selector: 'app-supplier-ivs-calibration-download',
  templateUrl: './supplier-ivs-calibration-download.component.html',
  styleUrls: ['./supplier-ivs-calibration-download.component.scss']
})
export class SupplierIvsCalibrationDownloadComponent {

}
