import { Component } from '@angular/core';

@Component({
  selector: 'app-firmware-description-and-owners',
  templateUrl: './firmware-description-and-owners.component.html',
  styleUrls: ['./firmware-description-and-owners.component.scss']
})
export class FirmwareDescriptionAndOwnersComponent {

}
