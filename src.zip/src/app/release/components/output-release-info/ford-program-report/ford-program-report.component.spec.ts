import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FordProgramReportComponent } from './ford-program-report.component';

describe('FordProgramReportComponent', () => {
  let component: FordProgramReportComponent;
  let fixture: ComponentFixture<FordProgramReportComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FordProgramReportComponent]
    });
    fixture = TestBed.createComponent(FordProgramReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
