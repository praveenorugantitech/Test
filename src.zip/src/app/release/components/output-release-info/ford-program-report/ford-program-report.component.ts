import { Component } from '@angular/core';

@Component({
  selector: 'app-ford-program-report',
  templateUrl: './ford-program-report.component.html',
  styleUrls: ['./ford-program-report.component.scss']
})
export class FordProgramReportComponent {

}
