import { Component } from '@angular/core';

@Component({
  selector: 'app-hcr',
  templateUrl: './hcr.component.html',
  styleUrls: ['./hcr.component.scss']
})
export class HcrComponent {

}
