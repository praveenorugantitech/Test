import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HcrComponent } from './hcr.component';

describe('HcrComponent', () => {
  let component: HcrComponent;
  let fixture: ComponentFixture<HcrComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HcrComponent]
    });
    fixture = TestBed.createComponent(HcrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
